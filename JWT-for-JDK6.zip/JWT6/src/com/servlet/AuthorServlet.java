package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jwt.Jwt;

public class AuthorServlet extends HttpServlet {

	private static final long serialVersionUID = -6756141343453275544L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String token=request.getHeader("token");
            System.out.println(token);
            try {
                Map<String, Object> result=Jwt.validToken(token);
                PrintWriter out = response.getWriter();
                out.println(result.get("isSuccess"));
                out.flush();
                out.close();
            } catch (Exception e) {
                System.out.println("异常");
                e.printStackTrace();
            }
    }
    
    public void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Map<String , Object> payload=new HashMap<String, Object>();
        Date date=new Date();
        payload.put("uid", "291969452");//用户id
        payload.put("iat", date.getTime());//生成时间
        payload.put("ext",date.getTime()+1000*60*60);//过期时间1小时
        String token=null;
        try {
            token=Jwt.createToken(payload);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        response.setContentType("text/html;charset=UTF-8;");
        Cookie cookie=new Cookie("token", token);
        cookie.setMaxAge(3600); 
        response.addCookie(cookie);
        PrintWriter out = response.getWriter();
        out.println(token);
        out.flush();
        out.close();
    }

}
